// Main JavaScript for Tokyo Train Transfer App

// Screen Management
function showScreen(screenId) {
    // Hide all screens
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    
    // Show selected screen
    document.getElementById(screenId).classList.add('active');
    
    // Initialize screen content if needed
    if (screenId === 'route-finder-screen') {
        initializeRouteFinder();
    } else if (screenId === 'vocabulary-screen') {
        initializeVocabulary();
    }
}

// Route Finder State
let selectedFrom = null;
let selectedTo = null;

function initializeRouteFinder() {
    const grid = document.getElementById('locations-grid');
    grid.innerHTML = '';
    
    locations.forEach(location => {
        const card = document.createElement('div');
        card.className = 'location-card';
        card.onclick = () => selectLocation(location.id);
        card.id = `location-${location.id}`;
        
        card.innerHTML = `
            <img src="${location.image}" alt="${location.name}" class="location-image" loading="lazy">
            <div class="location-name">
                ${location.name}
                <div class="location-name-jp">${location.nameJp}</div>
            </div>
        `;
        
        grid.appendChild(card);
    });
    
    // Reset selections
    selectedFrom = null;
    selectedTo = null;
    updateSelectionDisplay();
}

function selectLocation(locationId) {
    const card = document.getElementById(`location-${locationId}`);
    
    if (!selectedFrom) {
        // Select as 'from'
        selectedFrom = locationId;
        card.classList.add('from-selected');
        updateSelectionDisplay();
        updateAvailableDestinations();
    } else if (!selectedTo && locationId !== selectedFrom) {
        // Check if this location is reachable
        const isReachable = canReachLocation(selectedFrom, locationId);
        if (!isReachable) {
            alert('この ばしょへの ルートが ありません。\nមិនមានផ្លូវទៅកន្លែងនេះទេ។\nNo route available to this location.');
            return;
        }
        
        // Select as 'to'
        selectedTo = locationId;
        card.classList.add('to-selected');
        updateSelectionDisplay();
        document.getElementById('find-route-btn').disabled = false;
    } else {
        // Reset and start over
        document.querySelectorAll('.location-card').forEach(c => {
            c.classList.remove('from-selected', 'to-selected', 'unreachable');
        });
        selectedFrom = locationId;
        selectedTo = null;
        card.classList.add('from-selected');
        updateSelectionDisplay();
        updateAvailableDestinations();
        document.getElementById('find-route-btn').disabled = true;
    }
}

// Check if a location can be reached from the starting point
function canReachLocation(fromId, toId) {
    if (fromId === toId) return false;
    
    // Check direct route
    const routeKey = `${fromId}-${toId}`;
    const reverseKey = `${toId}-${fromId}`;
    if (trainRoutes[routeKey] || trainRoutes[reverseKey]) {
        return true;
    }
    
    // Check transfer route
    const transferRoute = findTransferRoute(fromId, toId);
    return transferRoute !== null;
}

// Update visual state of location cards based on reachability
function updateAvailableDestinations() {
    if (!selectedFrom) {
        // No selection, all locations available
        document.querySelectorAll('.location-card').forEach(card => {
            card.classList.remove('unreachable', 'direct-route', 'transfer-route');
            // Remove any existing badges
            const existingBadge = card.querySelector('.route-badge');
            if (existingBadge) {
                existingBadge.remove();
            }
        });
        return;
    }
    
    // Check each location
    locations.forEach(location => {
        const card = document.getElementById(`location-${location.id}`);
        if (location.id === selectedFrom) {
            // This is the starting location
            return;
        }
        
        // Remove existing badges
        const existingBadge = card.querySelector('.route-badge');
        if (existingBadge) {
            existingBadge.remove();
        }
        
        // Check direct route first
        const routeKey = `${selectedFrom}-${location.id}`;
        const reverseKey = `${location.id}-${selectedFrom}`;
        const hasDirectRoute = trainRoutes[routeKey] || trainRoutes[reverseKey];
        
        if (hasDirectRoute) {
            // Direct route available
            card.classList.remove('unreachable', 'transfer-route');
            card.classList.add('direct-route');
            
            // Add badge
            const badge = document.createElement('div');
            badge.className = 'route-badge direct-badge';
            badge.innerHTML = '<i class="fas fa-check-circle"></i> 乗り換えなし<br>Direct';
            card.appendChild(badge);
        } else {
            // Check for transfer route
            const transferRoute = findTransferRoute(selectedFrom, location.id);
            if (transferRoute) {
                // Transfer route available
                card.classList.remove('unreachable', 'direct-route');
                card.classList.add('transfer-route');
                
                // Add badge
                const badge = document.createElement('div');
                badge.className = 'route-badge transfer-badge';
                badge.innerHTML = '<i class="fas fa-exchange-alt"></i> 乗り換えあり<br>Transfer';
                card.appendChild(badge);
            } else {
                // No route available
                card.classList.add('unreachable');
                card.classList.remove('direct-route', 'transfer-route');
            }
        }
    });
}

function updateSelectionDisplay() {
    const fromDisplay = document.getElementById('from-location');
    const toDisplay = document.getElementById('to-location');
    
    // Get the parent selection boxes
    const fromBox = fromDisplay.closest('.selection-box');
    const toBox = toDisplay.closest('.selection-box');
    
    if (selectedFrom) {
        const fromLocation = locations.find(loc => loc.id === selectedFrom);
        fromDisplay.innerHTML = `🚉 ${fromLocation.name}<br><small style="font-size: 0.85em;">${fromLocation.nameJp}</small>`;
        fromDisplay.style.color = '#4CAF50';
        fromBox.classList.add('has-selection', 'from-box');
    } else {
        fromDisplay.innerHTML = '<i class="fas fa-map-marker-alt" style="opacity: 0.3; font-size: 2em;"></i><br>えらんでいません<br><small style="font-size: 0.8em;">Not selected / មិនទានជ្រើសរឺស</small>';
        fromDisplay.style.color = '#999';
        fromBox.classList.remove('has-selection', 'from-box');
    }
    
    if (selectedTo) {
        const toLocation = locations.find(loc => loc.id === selectedTo);
        toDisplay.innerHTML = `🎯 ${toLocation.name}<br><small style="font-size: 0.85em;">${toLocation.nameJp}</small>`;
        toDisplay.style.color = '#FF6B6B';
        toBox.classList.add('has-selection', 'to-box');
    } else {
        toDisplay.innerHTML = '<i class="fas fa-flag-checkered" style="opacity: 0.3; font-size: 2em;"></i><br>えらんでいません<br><small style="font-size: 0.8em;">Not selected / មិនទានជ្រើសរឺស</small>';
        toDisplay.style.color = '#999';
        toBox.classList.remove('has-selection', 'to-box');
    }
}

function findRoute() {
    if (!selectedFrom || !selectedTo) {
        alert('しゅっぱつち と もくてきちを えらんで ください。\nសូមជ្រើសរឺសទីចាក់ផ្តើម និង គោលដៅ។\nPlease select both departure and destination.');
        return;
    }
    
    const routeKey = `${selectedFrom}-${selectedTo}`;
    const reverseKey = `${selectedTo}-${selectedFrom}`;
    
    let route = trainRoutes[routeKey] || trainRoutes[reverseKey];
    
    const fromLocation = locations.find(loc => loc.id === selectedFrom);
    const toLocation = locations.find(loc => loc.id === selectedTo);
    
    const resultDiv = document.getElementById('route-result');
    
    if (route) {
        displayRouteResult(fromLocation, toLocation, route);
    } else {
        // Try to find a route with one transfer
        const transferRoute = findTransferRoute(selectedFrom, selectedTo);
        if (transferRoute) {
            displayTransferRoute(fromLocation, toLocation, transferRoute);
        } else {
            resultDiv.innerHTML = `
                <div style="text-align: center; padding: 40px;">
                    <div style="font-size: 2em; margin-bottom: 20px;">😔</div>
                    <h2 style="color: #333; margin-bottom: 15px;">ルートが みつかりません<br>Route Not Found</h2>
                    <p style="color: #666; font-size: 1.2em;">
                        この えきの あいだの ルートが ありません。<br>
                        <span style="font-size: 0.9em;">មិនមានភ្លូវរវាងស្ថានីទាំងពីរនេះទេ។</span><br>
                        <span style="font-size: 0.9em;">Sorry, we couldn't find a route between these stations.</span>
                    </p>
                </div>
            `;
        }
    }
    
    resultDiv.scrollIntoView({ behavior: 'smooth' });
}

function displayRouteResult(from, to, route) {
    const resultDiv = document.getElementById('route-result');
    
    resultDiv.innerHTML = `
        <h2 style="color: #333; text-align: center; margin-bottom: 30px;">
            <i class="fas fa-route"></i> Your Route<br>
            <span style="font-size: 0.85em; color: #666;">あなたのルート / ផ្លូវរបស់អ្នក</span>
        </h2>
        
        <div style="background: #f5f7fa; padding: 30px; border-radius: 15px; margin-bottom: 20px;">
            <div style="display: flex; justify-content: space-around; align-items: center; flex-wrap: wrap; gap: 20px;">
                <div style="text-align: center;">
                    <div style="font-size: 2em; color: #4CAF50; margin-bottom: 10px;">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div style="font-size: 1.5em; font-weight: bold;">${from.name}</div>
                    <div style="color: #666;">${from.nameJp}</div>
                </div>
                
                <div style="font-size: 2em; color: #667eea;">
                    <i class="fas fa-arrow-right"></i>
                </div>
                
                <div style="text-align: center;">
                    <div style="font-size: 2em; color: #FF6B6B; margin-bottom: 10px;">
                        <i class="fas fa-map-marker-alt"></i>
                    </div>
                    <div style="font-size: 1.5em; font-weight: bold;">${to.name}</div>
                    <div style="color: #666;">${to.nameJp}</div>
                </div>
            </div>
        </div>
        
        <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 15px; margin-bottom: 20px;">
            <h3 style="font-size: 1.8em; margin-bottom: 20px; text-align: center;">
                <i class="fas fa-train"></i> Direct Route<br>
                <span style="font-size: 0.75em; opacity: 0.9;">のりかえなし / ផ្លូវត្រង់</span>
            </h3>
            
            <div style="background: rgba(255,255,255,0.2); padding: 20px; border-radius: 10px; margin-bottom: 15px;">
                <strong style="font-size: 1.3em;">Line / せん / ខ្សែ:</strong><br>
                <span style="font-size: 1.5em; color: #D32F2F; background: rgba(211,47,47,0.15); padding: 5px 12px; border-radius: 8px; font-weight: bold;">${route.lines[0]}</span>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-top: 20px;">
                <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 0.9em; opacity: 0.8;">Time / じかん / ពេលវេលា</div>
                    <div style="font-size: 1.8em; font-weight: bold;">${route.time} min</div>
                </div>
                <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 0.9em; opacity: 0.8;">Fare / おかね / តម្លៃ</div>
                    <div style="font-size: 1.8em; font-weight: bold;">¥${route.fare}</div>
                </div>
                <div style="background: rgba(255,255,255,0.2); padding: 15px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 0.9em; opacity: 0.8;">Platform / のりば / ចំណតរថភ្លើង</div>
                    <div style="font-size: 1.8em; font-weight: bold;">${route.platform}</div>
                </div>
            </div>
        </div>
        
        <div style="background: #E8F5E9; padding: 25px; border-radius: 15px; border-left: 5px solid #4CAF50;">
            <h3 style="color: #2E7D32; margin-bottom: 15px; font-size: 1.5em;">
                <i class="fas fa-info-circle"></i> えいごで いう とき<br>
                <span style="font-size: 0.75em;">How to say in English / របៀបនិយាយជាភាសាអង់គ្លេស</span>
            </h3>
            <div style="font-size: 1.2em; color: #333; line-height: 1.8;">
                "Could you tell me how to get to <strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 3px 8px; border-radius: 5px;">${to.name}</strong>?"<br>
                <span style="font-style: italic; color: #666;"><strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 2px 6px; border-radius: 4px;">${to.nameJp}</strong>への いきかたを おしえて ください。</span><br>
                <span style="font-size: 0.85em; color: #888;">តើអ្នកអាចប្រាប់ខ្ញុំពីរបៀបទៅ${to.name}បានទេ?</span>
            </div>
            <div style="margin-top: 15px; font-size: 1.2em; color: #333; line-height: 1.8;">
                "Take the <strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 3px 8px; border-radius: 5px;">${route.lines[0]}</strong>."<br>
                <span style="font-style: italic; color: #666;"><strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 2px 6px; border-radius: 4px;">${route.lines[0]}</strong>に のって ください。</span><br>
                <span style="font-size: 0.85em; color: #888;">ជិះខ្សែ${route.lines[0]}។</span>
            </div>
        </div>
        
        <button onclick="resetRoute()" style="display: block; margin: 30px auto; padding: 15px 40px; font-size: 1.2em; background: #667eea; color: white; border: none; border-radius: 10px; cursor: pointer;">
            <i class="fas fa-redo"></i> べつの ルートを さがす<br>
            <span style="font-size: 0.75em; opacity: 0.9;">Try Another Route / ស្វែងរកផ្លូវផ្សេង</span>
        </button>
    `;
}

function findTransferRoute(fromId, toId) {
    // Simple transfer route finder
    // This is a simplified version - in a real app, you'd use a graph algorithm
    
    const possibleTransfers = ['ueno', 'tokyo', 'shibuya', 'shinjuku'];
    
    for (let transfer of possibleTransfers) {
        const leg1Key = `${fromId}-${transfer}`;
        const leg1ReverseKey = `${transfer}-${fromId}`;
        const leg2Key = `${transfer}-${toId}`;
        const leg2ReverseKey = `${toId}-${transfer}`;
        
        const leg1 = trainRoutes[leg1Key] || trainRoutes[leg1ReverseKey];
        const leg2 = trainRoutes[leg2Key] || trainRoutes[leg2ReverseKey];
        
        if (leg1 && leg2 && transfer !== fromId && transfer !== toId) {
            const transferLocation = locations.find(loc => loc.id === transfer);
            return {
                leg1: { route: leg1, to: transferLocation },
                leg2: { route: leg2 }
            };
        }
    }
    
    return null;
}

function displayTransferRoute(from, to, transferRoute) {
    const resultDiv = document.getElementById('route-result');
    const transferPoint = transferRoute.leg1.to;
    
    const totalTime = transferRoute.leg1.route.time + transferRoute.leg2.route.time + 3; // +3 min for transfer
    const totalFare = transferRoute.leg1.route.fare + transferRoute.leg2.route.fare;
    
    resultDiv.innerHTML = `
        <h2 style="color: #333; text-align: center; margin-bottom: 30px;">
            <i class="fas fa-route"></i> Your Route<br>
            <span style="font-size: 0.85em; color: #666;">あなたのルート / ភ្លូវរបស់អ្នក</span>
        </h2>
        
        <div style="background: linear-gradient(135deg, #FFA62E 0%, #FFD93D 100%); color: white; padding: 30px; border-radius: 15px; margin-bottom: 20px;">
            <h3 style="font-size: 1.8em; margin-bottom: 20px; text-align: center;">
                <i class="fas fa-exchange-alt"></i> のりかえ あり<br>
                <span style="font-size: 0.75em; opacity: 0.9;">Route with Transfer / ភ្លូវដែលមានប្ដូរផ្លាស់</span>
            </h3>
            
            <div style="background: rgba(255,255,255,0.3); padding: 25px; border-radius: 10px; margin-bottom: 20px;">
                <div style="font-size: 1.5em; font-weight: bold; margin-bottom: 10px;">
                    <i class="fas fa-circle" style="color: #4CAF50;"></i> Step 1: <span style="color: #4CAF50;">${from.name}</span> → <span style="color: #D32F2F;">${transferPoint.name}</span>
                </div>
                <div style="margin-left: 30px; font-size: 1.2em;">
                    <strong>Line / せん / ខ្សែ:</strong> <span style="color: #D32F2F; background: rgba(211,47,47,0.2); padding: 3px 10px; border-radius: 6px; font-weight: bold;">${transferRoute.leg1.route.lines[0]}</span><br>
                    <strong>Time / じかん / ពេលវេលា:</strong> ${transferRoute.leg1.route.time} minutes<br>
                    <strong>Platform / のりば / ចំណតរថភ្លើង:</strong> ${transferRoute.leg1.route.platform}
                </div>
            </div>
            
            <div style="text-align: center; font-size: 1.5em; margin: 20px 0; line-height: 1.6;">
                <i class="fas fa-exchange-alt"></i> <span style="color: #D32F2F; text-shadow: 2px 2px 4px rgba(0,0,0,0.3);">${transferPoint.name}</span> で のりかえ<br>
                <span style="font-size: 0.7em; opacity: 0.9;">Change trains at ${transferPoint.name} / ប្តូររថភ្លើងនៅ${transferPoint.name}</span>
            </div>
            
            <div style="background: rgba(255,255,255,0.3); padding: 25px; border-radius: 10px;">
                <div style="font-size: 1.5em; font-weight: bold; margin-bottom: 10px;">
                    <i class="fas fa-circle" style="color: #FF6B6B;"></i> Step 2: <span style="color: #D32F2F;">${transferPoint.name}</span> → <span style="color: #FF6B6B;">${to.name}</span>
                </div>
                <div style="margin-left: 30px; font-size: 1.2em;">
                    <strong>Line / せん / ខ្សែ:</strong> <span style="color: #D32F2F; background: rgba(211,47,47,0.2); padding: 3px 10px; border-radius: 6px; font-weight: bold;">${transferRoute.leg2.route.lines[0]}</span><br>
                    <strong>Time / じかん / ពេលវេលា:</strong> ${transferRoute.leg2.route.time} minutes<br>
                    <strong>Platform / のりば / ចំណតរថភ្លើង:</strong> ${transferRoute.leg2.route.platform}
                </div>
            </div>
            
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-top: 20px;">
                <div style="background: rgba(255,255,255,0.3); padding: 15px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 0.9em;">ぜんぶの じかん<br><span style="font-size: 0.8em;">Total Time / ពេលវេលាសរុប</span></div>
                    <div style="font-size: 1.8em; font-weight: bold;">${totalTime} min</div>
                </div>
                <div style="background: rgba(255,255,255,0.3); padding: 15px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 0.9em;">ぜんぶの おかね<br><span style="font-size: 0.8em;">Total Fare / តម្លៃសរុប</span></div>
                    <div style="font-size: 1.8em; font-weight: bold;">¥${totalFare}</div>
                </div>
                <div style="background: rgba(255,255,255,0.3); padding: 15px; border-radius: 10px; text-align: center;">
                    <div style="font-size: 0.9em;">のりかえ かいすう<br><span style="font-size: 0.8em;">Transfers / ចំនួនប្តូរ</span></div>
                    <div style="font-size: 1.8em; font-weight: bold;">1</div>
                </div>
            </div>
        </div>
        
        <div style="background: #E8F5E9; padding: 25px; border-radius: 15px; border-left: 5px solid #4CAF50;">
            <h3 style="color: #2E7D32; margin-bottom: 15px; font-size: 1.5em;">
                <i class="fas fa-comments"></i> えいごで いう とき<br>
                <span style="font-size: 0.75em;">English Conversation / ការនិយាយភាសាអង្គ្លេស</span>
            </h3>
            <div style="background: #FFE66D; padding: 15px; border-radius: 10px; margin-bottom: 15px; border-left: 5px solid #FFA500;">
                <strong>You:</strong> "Could you tell me how to get to <strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 3px 8px; border-radius: 5px;">${to.name}</strong>?"<br>
                <span style="font-style: italic; color: #666;"><strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 2px 6px; border-radius: 4px;">${to.nameJp}</strong>への いきかたを おしえて ください。</span><br>
                <span style="font-size: 0.85em; color: #888;">តើអ្នកអាចប្រាប់ខ្ញុំពីរបីយាបទៅ${to.name}បានទេ?</span>
            </div>
            <div style="background: #84C7F5; padding: 15px; border-radius: 10px; margin-bottom: 15px; border-left: 5px solid #2E5CFF; color: white;">
                <strong>Staff:</strong> "Take the <strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 3px 8px; border-radius: 5px;">${transferRoute.leg1.route.lines[0]}</strong> to <strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 3px 8px; border-radius: 5px;">${transferPoint.name}</strong> and change trains there."<br>
                <span style="font-style: italic; opacity: 0.9;"><strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 2px 6px; border-radius: 4px;">${transferRoute.leg1.route.lines[0]}</strong>で <strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 2px 6px; border-radius: 4px;">${transferPoint.nameJp}</strong>まで いって、そこで のりかえて ください。</span><br>
                <span style="font-size: 0.85em; opacity: 0.85;">ជិះខ្សែ<strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 2px 6px; border-radius: 4px;">${transferRoute.leg1.route.lines[0]}</strong>ទៅ<strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 2px 6px; border-radius: 4px;">${transferPoint.name}</strong> ហើយប្តូររថភ្លើងនៅទីនោះ។</span>
            </div>
            <div style="background: #FFE66D; padding: 15px; border-radius: 10px; margin-bottom: 15px; border-left: 5px solid #FFA500;">
                <strong>You:</strong> "Which line should I take from <strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 3px 8px; border-radius: 5px;">${transferPoint.name}</strong>?"<br>
                <span style="font-style: italic; color: #666;"><strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 2px 6px; border-radius: 4px;">${transferPoint.nameJp}</strong>から どの せんに のれば いいですか？</span><br>
                <span style="font-size: 0.85em; color: #888;">តើខ្ញុំគួរជិះខ្សែអ្វីពី<strong style="color: #D32F2F; background: rgba(211,47,47,0.15); padding: 2px 6px; border-radius: 4px;">${transferPoint.name}</strong>?</span>
            </div>
            <div style="background: #84C7F5; padding: 15px; border-radius: 10px; border-left: 5px solid #2E5CFF; color: white;">
                <strong>Staff:</strong> "Take the <strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 3px 8px; border-radius: 5px;">${transferRoute.leg2.route.lines[0]}</strong>."<br>
                <span style="font-style: italic; opacity: 0.9;"><strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 2px 6px; border-radius: 4px;">${transferRoute.leg2.route.lines[0]}</strong>に のって ください。</span><br>
                <span style="font-size: 0.85em; opacity: 0.85;">ជិះខ្សែ<strong style="color: #D32F2F; background: rgba(211,47,47,0.25); padding: 2px 6px; border-radius: 4px;">${transferRoute.leg2.route.lines[0]}</strong>។</span>
            </div>
        </div>
        
        <button onclick="resetRoute()" style="display: block; margin: 30px auto; padding: 15px 40px; font-size: 1.2em; background: #667eea; color: white; border: none; border-radius: 10px; cursor: pointer;">
            <i class="fas fa-redo"></i> べつの ルートを さがす<br>
            <span style="font-size: 0.75em; opacity: 0.9;">Try Another Route / ស្វែងរកភ្លូវផ្សេង</span>
        </button>
    `;
}

function resetRoute() {
    document.querySelectorAll('.location-card').forEach(card => {
        card.classList.remove('from-selected', 'to-selected', 'unreachable');
    });
    selectedFrom = null;
    selectedTo = null;
    updateSelectionDisplay();
    document.getElementById('find-route-btn').disabled = true;
    document.getElementById('route-result').innerHTML = '';
}

// Vocabulary Screen
function initializeVocabulary() {
    const grid = document.getElementById('vocabulary-grid');
    grid.innerHTML = '';
    
    railwayVocabulary.forEach(vocab => {
        const card = document.createElement('div');
        card.className = 'vocab-card';
        
        card.innerHTML = `
            <h3>${vocab.english}</h3>
            <div class="meaning">
                <ruby>${vocab.japanese}<rt>${vocab.furigana}</rt></ruby>
            </div>
            <div class="example">"${vocab.example}"</div>
        `;
        
        grid.appendChild(card);
    });
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    // Show welcome screen by default
    showScreen('welcome-screen');
});
