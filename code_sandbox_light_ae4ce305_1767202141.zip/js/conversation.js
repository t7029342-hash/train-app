// Conversation Practice JavaScript

let currentScenario = null;
let currentDialogueIndex = 0;
let currentPracticeMode = null;
let currentQuestionIndex = 0;
let practiceScore = 0;

// Initialize Conversation Practice
function startConversation(scenarioId) {
    currentScenario = conversationScenarios[scenarioId];
    currentDialogueIndex = 0;
    
    showScreen('dialogue-screen');
    
    // Set title
    document.getElementById('dialogue-title').innerHTML = `
        ${currentScenario.title}<br>
        <small style="color: #FFE66D;">${currentScenario.titleJp}</small>
    `;
    
    // Reset dialogue container
    document.getElementById('dialogue-container').innerHTML = '';
    
    // Show first dialogue
    displayDialogue();
    
    // Update vocabulary box
    updateVocabularyBox();
}

function displayDialogue() {
    if (currentDialogueIndex >= currentScenario.dialogues.length) {
        // All dialogues shown
        document.getElementById('next-btn').textContent = 'Complete! ✓';
        document.getElementById('next-btn').disabled = true;
        return;
    }
    
    const dialogue = currentScenario.dialogues[currentDialogueIndex];
    const container = document.getElementById('dialogue-container');
    
    // Create dialogue box
    const dialogueBox = document.createElement('div');
    
    // Check if this is a direct route scenario and if it's an answer
    if (dialogue.type === 'answer' && currentScenario.isDirect) {
        dialogueBox.className = 'dialogue-box answer-direct';
    } else {
        dialogueBox.className = `dialogue-box ${dialogue.type}`;
    }
    
    // Highlight vocabulary words and railway line names
    let highlightedText = dialogue.text;
    
    // First, highlight railway line names (anything ending with "Line")
    highlightedText = highlightedText.replace(/(\b[A-Z][a-zA-Z\s]*Line\b)/g, '<span class="line-name">$1</span>');
    
    // Then highlight other vocabulary words (skip if already highlighted as line name)
    dialogue.vocabulary.forEach(word => {
        if (!word.toLowerCase().includes('line')) {
            const regex = new RegExp(`\\b(${word})\\b`, 'gi');
            highlightedText = highlightedText.replace(regex, '<strong class="vocab-word">$1</strong>');
        }
    });
    
    dialogueBox.innerHTML = `
        <div style="margin-bottom: 10px;">
            <div style="font-weight: bold; font-size: 0.9em; margin-bottom: 5px; color: ${dialogue.type === 'question' ? '#FF6B35' : '#4ECDC4'};">
                ${dialogue.speaker}:
            </div>
            <div style="color: #333; font-weight: normal;">${highlightedText}</div>
        </div>
        <div class="dialogue-jp">${dialogue.textJp}</div>
    `;
    
    container.appendChild(dialogueBox);
    
    // Update progress
    const progress = ((currentDialogueIndex + 1) / currentScenario.dialogues.length) * 100;
    document.querySelector('.progress-fill').style.width = progress + '%';
    
    // Update step indicator
    const stepNum = Math.floor(currentDialogueIndex / 2) + 1;
    document.getElementById('step-indicator').innerHTML = `
        <i class="fas fa-walking"></i> Step ${stepNum}
    `;
    
    // Scroll to bottom
    dialogueBox.scrollIntoView({ behavior: 'smooth', block: 'end' });
    
    currentDialogueIndex++;
    
    // Update button text
    if (currentDialogueIndex >= currentScenario.dialogues.length) {
        document.getElementById('next-btn').innerHTML = 'Complete! <i class="fas fa-check"></i>';
    }
}

function showNextDialogue() {
    displayDialogue();
}

function updateVocabularyBox() {
    const vocabList = document.getElementById('vocabulary-list');
    vocabList.innerHTML = '';
    
    currentScenario.vocabulary.forEach(vocab => {
        const vocabItem = document.createElement('div');
        vocabItem.className = 'vocab-item';
        vocabItem.innerHTML = `
            <div class="vocab-english">${vocab.word}</div>
            <div class="vocab-japanese">${vocab.meaning}</div>
            <div class="vocab-example">"${vocab.example}"</div>
        `;
        vocabList.appendChild(vocabItem);
    });
}

function playCurrentAudio() {
    // Use Web Speech API to read the current dialogue
    if ('speechSynthesis' in window) {
        const dialogue = currentScenario.dialogues[currentDialogueIndex - 1];
        if (dialogue) {
            const utterance = new SpeechSynthesisUtterance(dialogue.text);
            utterance.lang = 'en-US';
            utterance.rate = 0.8; // Slower for learners
            window.speechSynthesis.speak(utterance);
        }
    } else {
        alert('お使いのブラウザは音声再生に対応していません。\nYour browser does not support audio playback.');
    }
}

// Practice Mode Functions
function startPracticeMode(mode) {
    currentPracticeMode = mode;
    currentQuestionIndex = 0;
    practiceScore = 0;
    
    showScreen('practice-screen');
    
    const scenarioNum = Object.keys(conversationScenarios).find(
        key => conversationScenarios[key] === currentScenario
    );
    
    if (mode === 'multiple-choice') {
        document.getElementById('practice-title').innerHTML = `
            📝 Multiple Choice Quiz<br>
            <small style="font-size: 0.6em; color: #FFE66D;">多肢選択クイズ</small>
        `;
        showMultipleChoiceQuestion(scenarioNum);
    } else if (mode === 'fill-blank') {
        document.getElementById('practice-title').innerHTML = `
            ✏️ Fill in the Blank<br>
            <small style="font-size: 0.6em; color: #FFE66D;">穴埋め問題</small>
        `;
        showFillBlankQuestion(scenarioNum);
    } else if (mode === 'role-play') {
        document.getElementById('practice-title').innerHTML = `
            🎭 Role Play Mode<br>
            <small style="font-size: 0.6em; color: #FFE66D;">ロールプレイモード</small>
        `;
        showRolePlayMode(scenarioNum);
    }
}

function showMultipleChoiceQuestion(scenarioNum) {
    const questions = practiceQuestions[scenarioNum];
    if (!questions || currentQuestionIndex >= questions.length) {
        showPracticeComplete();
        return;
    }
    
    const question = questions[currentQuestionIndex];
    const container = document.getElementById('practice-container');
    
    container.innerHTML = `
        <div class="question-box">
            <div style="font-size: 1.2em; margin-bottom: 10px;">${question.question}</div>
            <div style="font-size: 0.9em; color: #666;">${question.questionJp}</div>
        </div>
        <div class="answer-options" id="answer-options">
            ${question.options.map((option, index) => `
                <div class="answer-option" onclick="selectAnswer(${index})" data-index="${index}">
                    ${String.fromCharCode(65 + index)}. ${option}
                </div>
            `).join('')}
        </div>
    `;
    
    document.getElementById('check-answer-btn').style.display = 'block';
    document.getElementById('next-question-btn').style.display = 'none';
    document.getElementById('practice-result').innerHTML = '';
    document.getElementById('practice-result').className = 'practice-result';
}

function selectAnswer(index) {
    // Remove previous selections
    document.querySelectorAll('.answer-option').forEach(opt => {
        opt.classList.remove('selected');
    });
    
    // Add selected class
    const selected = document.querySelector(`[data-index="${index}"]`);
    selected.classList.add('selected');
    selected.dataset.selected = 'true';
}

function checkAnswer() {
    const scenarioNum = Object.keys(conversationScenarios).find(
        key => conversationScenarios[key] === currentScenario
    );
    
    if (currentPracticeMode === 'multiple-choice') {
        checkMultipleChoiceAnswer(scenarioNum);
    } else if (currentPracticeMode === 'fill-blank') {
        checkFillBlankAnswer(scenarioNum);
    }
}

function checkMultipleChoiceAnswer(scenarioNum) {
    const questions = practiceQuestions[scenarioNum];
    const question = questions[currentQuestionIndex];
    
    const selected = document.querySelector('.answer-option.selected');
    if (!selected) {
        alert('答えを選んでください。\nPlease select an answer.');
        return;
    }
    
    const selectedIndex = parseInt(selected.dataset.index);
    const resultDiv = document.getElementById('practice-result');
    
    if (selectedIndex === question.correct) {
        selected.classList.add('correct');
        resultDiv.className = 'practice-result correct';
        resultDiv.innerHTML = `
            <div style="font-size: 2em; margin-bottom: 10px;">🎉 Correct! / 正解！</div>
            <div style="font-size: 1em;">${question.explanation}</div>
        `;
        practiceScore++;
    } else {
        selected.classList.add('incorrect');
        const correctOption = document.querySelector(`[data-index="${question.correct}"]`);
        correctOption.classList.add('correct');
        
        resultDiv.className = 'practice-result incorrect';
        resultDiv.innerHTML = `
            <div style="font-size: 2em; margin-bottom: 10px;">❌ Incorrect / 不正解</div>
            <div style="font-size: 1em;">Correct answer: ${question.options[question.correct]}</div>
            <div style="font-size: 0.9em; margin-top: 10px;">${question.explanation}</div>
        `;
    }
    
    document.getElementById('check-answer-btn').style.display = 'none';
    document.getElementById('next-question-btn').style.display = 'block';
}

function showFillBlankQuestion(scenarioNum) {
    const questions = fillBlankQuestions[scenarioNum];
    if (!questions || currentQuestionIndex >= questions.length) {
        showPracticeComplete();
        return;
    }
    
    const question = questions[currentQuestionIndex];
    const container = document.getElementById('practice-container');
    
    container.innerHTML = `
        <div class="question-box">
            <div style="font-size: 1.2em; margin-bottom: 15px;">Fill in the blank:</div>
            <div style="font-size: 1.5em; margin-bottom: 10px;">${question.sentence}</div>
            <div style="font-size: 0.9em; color: #666;">ヒント: ${question.hint}</div>
        </div>
        <input type="text" id="fill-blank-input" class="fill-blank-input" placeholder="Type your answer here...">
    `;
    
    document.getElementById('check-answer-btn').style.display = 'block';
    document.getElementById('next-question-btn').style.display = 'none';
    document.getElementById('practice-result').innerHTML = '';
    document.getElementById('practice-result').className = 'practice-result';
}

function checkFillBlankAnswer(scenarioNum) {
    const questions = fillBlankQuestions[scenarioNum];
    const question = questions[currentQuestionIndex];
    
    const input = document.getElementById('fill-blank-input');
    const userAnswer = input.value.trim().toLowerCase();
    const correctAnswer = question.answer.toLowerCase();
    
    const resultDiv = document.getElementById('practice-result');
    
    if (userAnswer === correctAnswer) {
        resultDiv.className = 'practice-result correct';
        resultDiv.innerHTML = `
            <div style="font-size: 2em; margin-bottom: 10px;">🎉 Correct! / 正解！</div>
            <div style="font-size: 1em;">${question.explanation}</div>
        `;
        practiceScore++;
    } else {
        resultDiv.className = 'practice-result incorrect';
        resultDiv.innerHTML = `
            <div style="font-size: 2em; margin-bottom: 10px;">❌ Incorrect / 不正解</div>
            <div style="font-size: 1em;">Correct answer: <strong>${question.answer}</strong></div>
            <div style="font-size: 0.9em; margin-top: 10px;">${question.explanation}</div>
        `;
    }
    
    input.disabled = true;
    document.getElementById('check-answer-btn').style.display = 'none';
    document.getElementById('next-question-btn').style.display = 'block';
}

function showRolePlayMode(scenarioNum) {
    const container = document.getElementById('practice-container');
    const dialogues = currentScenario.dialogues;
    
    container.innerHTML = `
        <div class="role-play-container">
            <div class="role-indicator">
                🎭 You are the traveler asking for directions
                <div style="font-size: 0.8em; margin-top: 5px;">あなたは道を尋ねる旅行者です</div>
            </div>
            
            <div style="margin: 30px 0; text-align: center; font-size: 1.3em; color: white;">
                Practice reading the conversation out loud!<br>
                <span style="font-size: 0.8em;">会話を声に出して練習しましょう！</span>
            </div>
            
            ${dialogues.map((dialogue, index) => {
                // Determine the class based on whether it's a direct route
                let boxClass = dialogue.type;
                if (dialogue.type === 'answer' && currentScenario.isDirect) {
                    boxClass = 'answer-direct';
                }
                
                return `
                <div class="dialogue-box ${boxClass}" style="margin-bottom: 15px;">
                    <div style="margin-bottom: 10px;">
                        <div style="font-weight: bold; font-size: 0.9em; margin-bottom: 5px; color: ${dialogue.type === 'question' ? '#FF6B35' : '#4ECDC4'};">
                            ${dialogue.speaker}:
                        </div>
                        <div style="color: #333; font-weight: normal;">${dialogue.text}</div>
                    </div>
                    <div class="dialogue-jp">${dialogue.textJp}</div>
                    <button onclick="speakLine(${index})" style="margin-top: 10px; padding: 8px 15px; border: none; border-radius: 5px; background: #E0E0E0; cursor: pointer; color: #333;">
                        <i class="fas fa-volume-up"></i> Play
                    </button>
                </div>`;
            }).join('')}
            `).join('')}
            
            <div style="margin-top: 30px; padding: 20px; background: rgba(255,255,255,0.1); border-radius: 10px; text-align: center;">
                <button class="record-btn" onclick="toggleRecording()" id="record-btn">
                    <i class="fas fa-microphone"></i>
                </button>
                <div style="color: white; margin-top: 10px;">
                    Record yourself and practice!<br>
                    <span style="font-size: 0.8em;">自分の声を録音して練習しよう！</span>
                </div>
            </div>
        </div>
    `;
    
    document.getElementById('check-answer-btn').style.display = 'none';
    document.getElementById('next-question-btn').style.display = 'none';
    document.getElementById('practice-result').innerHTML = '';
}

function speakLine(index) {
    if ('speechSynthesis' in window) {
        const dialogue = currentScenario.dialogues[index];
        const utterance = new SpeechSynthesisUtterance(dialogue.text);
        utterance.lang = 'en-US';
        utterance.rate = 0.8;
        window.speechSynthesis.speak(utterance);
    }
}

let isRecording = false;
let mediaRecorder = null;

function toggleRecording() {
    const btn = document.getElementById('record-btn');
    
    if (!isRecording) {
        startRecording(btn);
    } else {
        stopRecording(btn);
    }
}

function startRecording(btn) {
    if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        navigator.mediaDevices.getUserMedia({ audio: true })
            .then(stream => {
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.start();
                isRecording = true;
                btn.classList.add('recording');
                btn.innerHTML = '<i class="fas fa-stop"></i>';
                
                mediaRecorder.ondataavailable = (e) => {
                    // Handle recorded data
                };
            })
            .catch(err => {
                alert('マイクへのアクセスが許可されていません。\nMicrophone access denied.');
            });
    } else {
        alert('お使いのブラウザは録音に対応していません。\nYour browser does not support recording.');
    }
}

function stopRecording(btn) {
    if (mediaRecorder) {
        mediaRecorder.stop();
        mediaRecorder.stream.getTracks().forEach(track => track.stop());
        isRecording = false;
        btn.classList.remove('recording');
        btn.innerHTML = '<i class="fas fa-microphone"></i>';
        
        alert('録音完了！\nRecording complete!');
    }
}

function nextQuestion() {
    currentQuestionIndex++;
    
    const scenarioNum = Object.keys(conversationScenarios).find(
        key => conversationScenarios[key] === currentScenario
    );
    
    if (currentPracticeMode === 'multiple-choice') {
        showMultipleChoiceQuestion(scenarioNum);
    } else if (currentPracticeMode === 'fill-blank') {
        showFillBlankQuestion(scenarioNum);
    }
}

function showPracticeComplete() {
    const container = document.getElementById('practice-container');
    const totalQuestions = currentQuestionIndex;
    const percentage = totalQuestions > 0 ? Math.round((practiceScore / totalQuestions) * 100) : 0;
    
    container.innerHTML = `
        <div style="text-align: center; padding: 50px 20px;">
            <div style="font-size: 3em; margin-bottom: 20px;">
                ${percentage >= 80 ? '🏆' : percentage >= 60 ? '👍' : '💪'}
            </div>
            <div style="font-size: 2em; color: #333; margin-bottom: 10px;">
                Practice Complete! / 練習完了！
            </div>
            <div style="font-size: 1.5em; color: #666; margin-bottom: 30px;">
                Score: ${practiceScore} / ${totalQuestions} (${percentage}%)
            </div>
            <div style="font-size: 1.2em; color: #888;">
                ${percentage >= 80 ? 'Excellent work! / 素晴らしい！' : 
                  percentage >= 60 ? 'Good job! Keep practicing! / よくできました！' : 
                  'Keep trying! You can do it! / 頑張りましょう！'}
            </div>
        </div>
    `;
    
    document.getElementById('check-answer-btn').style.display = 'none';
    document.getElementById('next-question-btn').style.display = 'none';
}

function backToDialogue() {
    showScreen('dialogue-screen');
}
